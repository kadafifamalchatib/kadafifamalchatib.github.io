self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "f0dd7db0d97a2eeb4dc1a66e5d663e41",
    "url": "./index.html"
  },
  {
    "revision": "22fddf1ab48d40761699",
    "url": "./static/css/main.c1a34960.chunk.css"
  },
  {
    "revision": "9d2baab37fad2360ae60",
    "url": "./static/js/23.fbc4785f.chunk.js"
  },
  {
    "revision": "e15e83db23e794a86a210f6e7497ab09",
    "url": "./static/js/23.fbc4785f.chunk.js.LICENSE.txt"
  },
  {
    "revision": "22379b5411c3f8c756e5",
    "url": "./static/js/24.b0e4be24.chunk.js"
  },
  {
    "revision": "e1a15f3ac9ac1f3abbbb282780755415",
    "url": "./static/js/24.b0e4be24.chunk.js.LICENSE.txt"
  },
  {
    "revision": "ca3305de4286f4b0b25b",
    "url": "./static/js/25.9a6d872d.chunk.js"
  },
  {
    "revision": "ee475d0f996b9ea7053f",
    "url": "./static/js/26.4dad7343.chunk.js"
  },
  {
    "revision": "e7a91dd2aa196f7e5b8f54f2566cde7f",
    "url": "./static/js/26.4dad7343.chunk.js.LICENSE.txt"
  },
  {
    "revision": "e3b7ec4de531284e69e0",
    "url": "./static/js/27.735ba3ea.chunk.js"
  },
  {
    "revision": "4346c6cbfaae129ac42a",
    "url": "./static/js/28.d3b5818b.chunk.js"
  },
  {
    "revision": "2391745417a8b740cccf",
    "url": "./static/js/29.dd4b2d05.chunk.js"
  },
  {
    "revision": "55400ae53c0618c79a84",
    "url": "./static/js/30.a92d1320.chunk.js"
  },
  {
    "revision": "48eaad91a0bbcaba5d06",
    "url": "./static/js/31.b2debaed.chunk.js"
  },
  {
    "revision": "ff1223435474e36a9c59",
    "url": "./static/js/32.21d7d4f5.chunk.js"
  },
  {
    "revision": "74012f5985a33225c0be",
    "url": "./static/js/33.c1f9826a.chunk.js"
  },
  {
    "revision": "132d4fa142257e161a82",
    "url": "./static/js/34.5784a965.chunk.js"
  },
  {
    "revision": "bcf3df6893df8283fc8b",
    "url": "./static/js/35.3109008d.chunk.js"
  },
  {
    "revision": "79eaa640c02f7a840f88",
    "url": "./static/js/36.fdf71fc7.chunk.js"
  },
  {
    "revision": "ef998acd8f65ae6b9b420793d7484b0e",
    "url": "./static/js/36.fdf71fc7.chunk.js.LICENSE.txt"
  },
  {
    "revision": "b1305a8ac3c17b87a669",
    "url": "./static/js/5.e7eab90a.chunk.js"
  },
  {
    "revision": "ed2142ca8416afcc9c62",
    "url": "./static/js/about-page.3c7eacdd.chunk.js"
  },
  {
    "revision": "bb59a5474acf48acdfdb",
    "url": "./static/js/add-liquidity-page.96441e5b.chunk.js"
  },
  {
    "revision": "85b19ba5699884e6a40f",
    "url": "./static/js/add-liquidity-page~create-pool-page~redirect-create-pool-duplicate-token-ids-page~redirect-old-creat~97c95ca7.efbef3af.chunk.js"
  },
  {
    "revision": "eb55e02502508d40ffdc",
    "url": "./static/js/add-liquidity-page~pool-finder-page~pool-page~remove-liquidity-page.c772bb54.chunk.js"
  },
  {
    "revision": "45aca0e2623ff75335ef",
    "url": "./static/js/create-pool-page.58fc9d41.chunk.js"
  },
  {
    "revision": "60fdda55d7431e9023a3",
    "url": "./static/js/create-referral-page.6d0ef64c.chunk.js"
  },
  {
    "revision": "f43959ed67a7a127e9b9",
    "url": "./static/js/ethers.b62fc8d6.chunk.js"
  },
  {
    "revision": "62684652de3eae6d31502c7569329a82",
    "url": "./static/js/ethers.b62fc8d6.chunk.js.LICENSE.txt"
  },
  {
    "revision": "22fddf1ab48d40761699",
    "url": "./static/js/main.dbec3416.chunk.js"
  },
  {
    "revision": "6342f9d8fbe808ffff68e7f4c5639c84",
    "url": "./static/js/main.dbec3416.chunk.js.LICENSE.txt"
  },
  {
    "revision": "3e1bbdd7b650be30b24d",
    "url": "./static/js/migrate-sushi-page.6076c567.chunk.js"
  },
  {
    "revision": "a7265af4946179609b6b",
    "url": "./static/js/migrate-sushi-page~migrate-uni-page~remove-liquidity-page.6783acd9.chunk.js"
  },
  {
    "revision": "754e31f6d0366443265d",
    "url": "./static/js/migrate-uni-page.749a7df1.chunk.js"
  },
  {
    "revision": "8cbda38bf8fdca1f4291",
    "url": "./static/js/migration-page.85ff1eef.chunk.js"
  },
  {
    "revision": "9f952442e2e15e9e74d0",
    "url": "./static/js/migration-page~pool-finder-external-page.3b2f083b.chunk.js"
  },
  {
    "revision": "43f0450e33d2c2e277b9",
    "url": "./static/js/pool-finder-external-page.74e54d4e.chunk.js"
  },
  {
    "revision": "6655a2fd4f1647ac9caa",
    "url": "./static/js/pool-finder-page.46344a1c.chunk.js"
  },
  {
    "revision": "6e5186701472dad72df2",
    "url": "./static/js/pool-page.fc8c172d.chunk.js"
  },
  {
    "revision": "5a5d51ff1b29971a3d97",
    "url": "./static/js/pools-page.2c582945.chunk.js"
  },
  {
    "revision": "0fee1943d6cf9daaad21",
    "url": "./static/js/redirect-create-pool-duplicate-token-ids-page.c5cec02f.chunk.js"
  },
  {
    "revision": "c2b7514be0330258f4b9",
    "url": "./static/js/redirect-old-create-pool-path-structure-page.d977387e.chunk.js"
  },
  {
    "revision": "d999ce04dc604f6ad632",
    "url": "./static/js/remove-liquidity-page.8552a65f.chunk.js"
  },
  {
    "revision": "978d79503fcf28bfb5c2",
    "url": "./static/js/runtime-main.234e7a00.js"
  },
  {
    "revision": "3ec4ed58facef3b669c3",
    "url": "./static/js/yield-page.1c002bc5.chunk.js"
  },
  {
    "revision": "b8934e8e46956328e2e479a15f2d1185",
    "url": "./static/media/Arbitrum_HorizontalLogo-dark.b8934e8e.svg"
  },
  {
    "revision": "42f6f7e2efb19a7830260766d314974f",
    "url": "./static/media/Arbitrum_HorizontalLogo.42f6f7e2.svg"
  },
  {
    "revision": "f89eb28eade0c1b755e051408dcc5825",
    "url": "./static/media/Farm.f89eb28e.svg"
  },
  {
    "revision": "09f4068bb74fc78ffbce74f5596d6aa5",
    "url": "./static/media/Inter-Black.09f4068b.woff2"
  },
  {
    "revision": "e37354838bf8078ac0d296217613533f",
    "url": "./static/media/Inter-Black.e3735483.woff"
  },
  {
    "revision": "07e69b53f8cf91da94096d1abf484302",
    "url": "./static/media/Inter-BlackItalic.07e69b53.woff"
  },
  {
    "revision": "daa1ca3cebd42cf5ebd53d9a6942b2cf",
    "url": "./static/media/Inter-BlackItalic.daa1ca3c.woff2"
  },
  {
    "revision": "79260e5b693fac2ee373b659f01a2bdf",
    "url": "./static/media/Inter-Bold.79260e5b.woff"
  },
  {
    "revision": "aed27700d84e327fda56b4a427b03061",
    "url": "./static/media/Inter-Bold.aed27700.woff2"
  },
  {
    "revision": "8ef77a031c5b96e53f2eeeb009232181",
    "url": "./static/media/Inter-BoldItalic.8ef77a03.woff2"
  },
  {
    "revision": "e0879d64763e509f309940120e7d1f5a",
    "url": "./static/media/Inter-BoldItalic.e0879d64.woff"
  },
  {
    "revision": "38bc51bccb7dd07b2752c11888cbdc89",
    "url": "./static/media/Inter-ExtraBold.38bc51bc.woff"
  },
  {
    "revision": "92d16aee8fb5f5c5cfd660b2d07e1148",
    "url": "./static/media/Inter-ExtraBold.92d16aee.woff2"
  },
  {
    "revision": "0e4b21ebad8d568078450713ee9339cf",
    "url": "./static/media/Inter-ExtraBoldItalic.0e4b21eb.woff"
  },
  {
    "revision": "57ea76d011f6fff8cb7013b783bad58e",
    "url": "./static/media/Inter-ExtraBoldItalic.57ea76d0.woff2"
  },
  {
    "revision": "4bd040df09ea4765148b5743b8493e5f",
    "url": "./static/media/Inter-ExtraLight.4bd040df.woff"
  },
  {
    "revision": "4d9f96f8504cd034ef7e5f25434ca550",
    "url": "./static/media/Inter-ExtraLight.4d9f96f8.woff2"
  },
  {
    "revision": "54d3d9a59ea904ebd11c3ac308893bfb",
    "url": "./static/media/Inter-ExtraLightItalic.54d3d9a5.woff2"
  },
  {
    "revision": "84c26656e02913a54131fc64431212ae",
    "url": "./static/media/Inter-ExtraLightItalic.84c26656.woff"
  },
  {
    "revision": "9528384cf7aebfa81a198626cb05f5e8",
    "url": "./static/media/Inter-Italic.9528384c.woff2"
  },
  {
    "revision": "e4ad3666e223c64e4df963cec740bf09",
    "url": "./static/media/Inter-Italic.e4ad3666.woff"
  },
  {
    "revision": "5baca21acf845c8e746f08675f40300b",
    "url": "./static/media/Inter-Light.5baca21a.woff2"
  },
  {
    "revision": "b9920de0749addeb5a53462fb5bbe070",
    "url": "./static/media/Inter-Light.b9920de0.woff"
  },
  {
    "revision": "0555a46cda7fc3406a875d6bacf8fcff",
    "url": "./static/media/Inter-LightItalic.0555a46c.woff"
  },
  {
    "revision": "adc70179a9e60e14f2a4f7d106166004",
    "url": "./static/media/Inter-LightItalic.adc70179.woff2"
  },
  {
    "revision": "7a8cc7241f766a142e15b2948804e547",
    "url": "./static/media/Inter-Medium.7a8cc724.woff"
  },
  {
    "revision": "f6cf0a0bc5fce3307e2c426eb14eb752",
    "url": "./static/media/Inter-Medium.f6cf0a0b.woff2"
  },
  {
    "revision": "417907d2be56d39b2a9c0b52fc8a00e8",
    "url": "./static/media/Inter-MediumItalic.417907d2.woff"
  },
  {
    "revision": "565a7104c497ccb1bf12832d8b341861",
    "url": "./static/media/Inter-MediumItalic.565a7104.woff2"
  },
  {
    "revision": "4dd66a113d54a7f9a1ae913049610617",
    "url": "./static/media/Inter-Regular.4dd66a11.woff2"
  },
  {
    "revision": "7c539936c4c8c822b59a1bcc6c08a6ec",
    "url": "./static/media/Inter-Regular.7c539936.woff"
  },
  {
    "revision": "1db6c55ca0f2a97fbce3b0b3903a7bb7",
    "url": "./static/media/Inter-SemiBold.1db6c55c.woff"
  },
  {
    "revision": "dd8a55ef7058cdaeb96ef9fc65344726",
    "url": "./static/media/Inter-SemiBold.dd8a55ef.woff2"
  },
  {
    "revision": "81678d1a50a895cc1232f3e287976083",
    "url": "./static/media/Inter-SemiBoldItalic.81678d1a.woff"
  },
  {
    "revision": "ac201e30486307c75c5038f61df9fd9f",
    "url": "./static/media/Inter-SemiBoldItalic.ac201e30.woff2"
  },
  {
    "revision": "850febbe5e8a7625c5603061d2e7c0ce",
    "url": "./static/media/Inter-Thin.850febbe.woff2"
  },
  {
    "revision": "ead42837911f0b55b0877c12b50d9157",
    "url": "./static/media/Inter-Thin.ead42837.woff"
  },
  {
    "revision": "a76db06556290ed3bd198a72b24d8006",
    "url": "./static/media/Inter-ThinItalic.a76db065.woff"
  },
  {
    "revision": "e08d9b2a5079b81cc39804c2a7406254",
    "url": "./static/media/Inter-ThinItalic.e08d9b2a.woff2"
  },
  {
    "revision": "2690e3c25733fb852b55b3f8d651a431",
    "url": "./static/media/Inter-italic.var.2690e3c2.woff2"
  },
  {
    "revision": "90e8f61d26f65b5ff0acc45ddf6740ea",
    "url": "./static/media/Inter-roman.var.90e8f61d.woff2"
  },
  {
    "revision": "4b976905f2be1cb9201f5d94afd9edd2",
    "url": "./static/media/Inter.var.4b976905.woff2"
  },
  {
    "revision": "311f174003cfafe8d82ead34f5b76ad7",
    "url": "./static/media/KNC.311f1740.svg"
  },
  {
    "revision": "814d311862e14cc0305b97279e2ddeef",
    "url": "./static/media/LM-desktop.814d3118.png"
  },
  {
    "revision": "42d8acb7ca4be2c8a02812c9d8486f4d",
    "url": "./static/media/LM-mobile-300dpi.42d8acb7.png"
  },
  {
    "revision": "2a8d4182ba119d1e6ecc809ca866df51",
    "url": "./static/media/LM-tablet.2a8d4182.png"
  },
  {
    "revision": "178a004ff3f05febc413e4d889a81f07",
    "url": "./static/media/about_background.178a004f.png"
  },
  {
    "revision": "dc9464883b28d1e368f8776d8e05c486",
    "url": "./static/media/about_icon_avalanche.dc946488.svg"
  },
  {
    "revision": "de97788694f6b125ea53923ac349d88b",
    "url": "./static/media/about_icon_bsc.de977886.svg"
  },
  {
    "revision": "ab721f0c4e74dc96e5586cb4f4d8b2bf",
    "url": "./static/media/about_icon_bug_bounty.ab721f0c.svg"
  },
  {
    "revision": "064ace4777ac86d7627f455f36975452",
    "url": "./static/media/about_icon_github.064ace47.png"
  },
  {
    "revision": "cefc20232703e5e3c24efd5f50d75e26",
    "url": "./static/media/about_icon_github_light.cefc2023.png"
  },
  {
    "revision": "2004cba49ea6de741d22649dcf0068fb",
    "url": "./static/media/about_icon_kyber.2004cba4.svg"
  },
  {
    "revision": "1ceb77b34221f7067757722e0157278e",
    "url": "./static/media/about_icon_kyber_light.1ceb77b3.svg"
  },
  {
    "revision": "29d8a06cce1c7c21ebf82d53bfacab4f",
    "url": "./static/media/alert.29d8a06c.svg"
  },
  {
    "revision": "261f0ca6bcf3d211716825c80a1d2a70",
    "url": "./static/media/arbitrum-network.261f0ca6.svg"
  },
  {
    "revision": "e96d8158ff6d3087ab15e43e64fbb47e",
    "url": "./static/media/arrow-right.e96d8158.svg"
  },
  {
    "revision": "0b5d697eb4752393f79f4b4ceb0eb194",
    "url": "./static/media/aurora-network.0b5d697e.svg"
  },
  {
    "revision": "2565884a03843bf5f37bf4a806402acf",
    "url": "./static/media/avax-network.2565884a.png"
  },
  {
    "revision": "f0630804afe19a0b2f51467a98c1f4c0",
    "url": "./static/media/banner_1_desktop.f0630804.png"
  },
  {
    "revision": "73063e6f39ccc6402eca9d1a569cdeb4",
    "url": "./static/media/banner_1_mobile.73063e6f.png"
  },
  {
    "revision": "235ad99d18f9fe8f60f8bd6a63ad86e2",
    "url": "./static/media/banner_1_tablet.235ad99d.png"
  },
  {
    "revision": "e12cd30b86715f6efe3d896a573fdfdb",
    "url": "./static/media/banner_2_desktop.e12cd30b.png"
  },
  {
    "revision": "90491b98cd255d9b3263d1be516a939c",
    "url": "./static/media/banner_2_mobile.90491b98.png"
  },
  {
    "revision": "1a80881e3541b7dac3b2ef85328fe68c",
    "url": "./static/media/banner_2_tablet.1a80881e.png"
  },
  {
    "revision": "a06e8e4141cdc0a95750318a99d65601",
    "url": "./static/media/bar_chart_icon.a06e8e41.svg"
  },
  {
    "revision": "3de5556767e5ad43641b532a11b9da3e",
    "url": "./static/media/big_unicorn.3de55567.png"
  },
  {
    "revision": "ca906475cf6fd6f3f93ce3010d42ccad",
    "url": "./static/media/blue-loader.ca906475.svg"
  },
  {
    "revision": "790d94abb21da6c3c9a02af78d3cab31",
    "url": "./static/media/bnb-logo.790d94ab.png"
  },
  {
    "revision": "2ce32840b5ac72fca6aec89414edfd6c",
    "url": "./static/media/bronze_icon.2ce32840.svg"
  },
  {
    "revision": "9b5affc50d2f23339ff25772eec98810",
    "url": "./static/media/btt-logo-dark.9b5affc5.svg"
  },
  {
    "revision": "f151e7c034cf9bfe25d6300fe783f545",
    "url": "./static/media/btt-logo.f151e7c0.svg"
  },
  {
    "revision": "264e7f9dc8378ada246fde68fbc7c193",
    "url": "./static/media/chainsecurity.264e7f9d.svg"
  },
  {
    "revision": "b3cefb821d4adb8d313d8a7fef173fa9",
    "url": "./static/media/coin98.b3cefb82.svg"
  },
  {
    "revision": "aa4c7a7647abc7ede02e017c1a0141b6",
    "url": "./static/media/coinbaseWalletIcon.aa4c7a76.svg"
  },
  {
    "revision": "b0f796cb94a7471cff1f878f20652ab9",
    "url": "./static/media/coingecko-light.b0f796cb.svg"
  },
  {
    "revision": "211cbb75a725474fd399262458dd6fbe",
    "url": "./static/media/coingecko.211cbb75.svg"
  },
  {
    "revision": "4e156b70b62b6a1775946bc766a839dd",
    "url": "./static/media/cronos-network.4e156b70.png"
  },
  {
    "revision": "1f3f9a693a985ff78997bee412095edb",
    "url": "./static/media/cronos-token-logo.1f3f9a69.svg"
  },
  {
    "revision": "1ab792added1a2909f1c6c24d3d1db5a",
    "url": "./static/media/discover_icon.1ab792ad.svg"
  },
  {
    "revision": "1b0642a517fc5045c1d65335f5835d64",
    "url": "./static/media/discover_icon_triangle.1b0642a5.svg"
  },
  {
    "revision": "50dbd07d8e7428d04464644f7cf819cf",
    "url": "./static/media/dropdown.50dbd07d.svg"
  },
  {
    "revision": "84abde3d96f0a27e196d333c327aa308",
    "url": "./static/media/en-US.84abde3d.po"
  },
  {
    "revision": "00d4c5ff40e0391b1d55522373c67794",
    "url": "./static/media/enter 1.00d4c5ff.svg"
  },
  {
    "revision": "97434d251c2ee5b23fa7eacf1feb9e2a",
    "url": "./static/media/flag-EN.97434d25.svg"
  },
  {
    "revision": "86034cb4aa4aef391c8fb78cc5bce9ce",
    "url": "./static/media/flag-KO.86034cb4.svg"
  },
  {
    "revision": "ab55913474f1155e122eb80b7c9723c7",
    "url": "./static/media/flag-TR.ab559134.svg"
  },
  {
    "revision": "27a98faad1a92e261be8b1028c9640be",
    "url": "./static/media/flag-VI.27a98faa.svg"
  },
  {
    "revision": "b8dc44eadf08fceb393ff9ff7da35018",
    "url": "./static/media/flag-ZH.b8dc44ea.svg"
  },
  {
    "revision": "288d23af354fda8a07a6bc5760a2bd13",
    "url": "./static/media/for_trader.288d23af.svg"
  },
  {
    "revision": "915255b136df2650b77bdfdddd9e58bf",
    "url": "./static/media/for_trader_light.915255b1.svg"
  },
  {
    "revision": "05363b2ff78c77d09c03af3b758fb4ff",
    "url": "./static/media/gold_icon.05363b2f.svg"
  },
  {
    "revision": "cbcbd4ffcd06d36e98487544c8055405",
    "url": "./static/media/icon_lock.cbcbd4ff.svg"
  },
  {
    "revision": "e8301ea3f39e7af0ea9608d738bf204c",
    "url": "./static/media/ko-KR.e8301ea3.po"
  },
  {
    "revision": "ac559920e4afae9b2d1394a54493987e",
    "url": "./static/media/ledger.ac559920.svg"
  },
  {
    "revision": "e96d8158ff6d3087ab15e43e64fbb47e",
    "url": "./static/media/light-arrow-right.e96d8158.svg"
  },
  {
    "revision": "bb693bc8933611ab0b5885d352b061aa",
    "url": "./static/media/light-coin98.bb693bc8.svg"
  },
  {
    "revision": "855d8c75ac6a6312e64215d5afefe400",
    "url": "./static/media/light-ledger.855d8c75.svg"
  },
  {
    "revision": "d429e24d3cddc2b793580c0bce53b8c7",
    "url": "./static/media/light-metamask.d429e24d.svg"
  },
  {
    "revision": "3f0bfcf6f52eea52c97435143e58b17a",
    "url": "./static/media/light-trezor.3f0bfcf6.svg"
  },
  {
    "revision": "a18d398b5969c98a35025f00c560ceb1",
    "url": "./static/media/light-wallet-connect.a18d398b.svg"
  },
  {
    "revision": "2e6d95876232eb9eef07ad3841a5ad82",
    "url": "./static/media/light-wallet-link.2e6d9587.svg"
  },
  {
    "revision": "0809ccc8f9c7520d49fc0c1ac7e756aa",
    "url": "./static/media/mainnet-network.0809ccc8.svg"
  },
  {
    "revision": "981ecca4e2e244ff635162cbb11b69ac",
    "url": "./static/media/menu.981ecca4.svg"
  },
  {
    "revision": "023762b6aec2a2249b8fdfb638f00ef3",
    "url": "./static/media/metamask.023762b6.png"
  },
  {
    "revision": "4305ec3053aded3962ef5d6e315ba6e8",
    "url": "./static/media/metamask.4305ec30.svg"
  },
  {
    "revision": "17ab2292f09e7d21aa126b0d0cd2f154",
    "url": "./static/media/noise.17ab2292.png"
  },
  {
    "revision": "55b4088cf8c4bc5709739aa178005a90",
    "url": "./static/media/notification_icon_failure.55b4088c.svg"
  },
  {
    "revision": "1886bcc3d3aff71f73dbc3c13e6247a3",
    "url": "./static/media/notification_icon_success.1886bcc3.svg"
  },
  {
    "revision": "a67cca8f3513b12a9164bc23b4f5d482",
    "url": "./static/media/oasis-network.a67cca8f.svg"
  },
  {
    "revision": "b234b2bfa0417c7e8711c3a8d17afeec",
    "url": "./static/media/portisIcon.b234b2bf.png"
  },
  {
    "revision": "78b8d0b8cb5f542d453bb826d9ed7556",
    "url": "./static/media/seamless.78b8d0b8.svg"
  },
  {
    "revision": "fe406c15730af4a904d145b478e7621b",
    "url": "./static/media/signal_cellular_alt_black_24dp 3.fe406c15.svg"
  },
  {
    "revision": "79f2b794bdb2a38e8416b0fdab6b3966",
    "url": "./static/media/silver_icon.79f2b794.svg"
  },
  {
    "revision": "82e5bdfc33283197e7e8de97d50fbe6d",
    "url": "./static/media/sushiswap-icon.82e5bdfc.svg"
  },
  {
    "revision": "5e040b2bbfcde1941d9e9ef5bbbf6d14",
    "url": "./static/media/swap.5e040b2b.svg"
  },
  {
    "revision": "2a1ce5297aaeee9f1c2faf819bd726d1",
    "url": "./static/media/switch.2a1ce529.svg"
  },
  {
    "revision": "7a5b585dd47182a9103f17206b7bf1d4",
    "url": "./static/media/tl-PH.7a5b585d.po"
  },
  {
    "revision": "b58200ac6d0a973dbd1f4170345b6bb4",
    "url": "./static/media/tokenlist.b58200ac.svg"
  },
  {
    "revision": "3b6934a557e6dd94199a7098dcab5159",
    "url": "./static/media/tr-TR.3b6934a5.po"
  },
  {
    "revision": "01b480573f2f97932bf6b155f8fe91f0",
    "url": "./static/media/trending_hero_laptop.01b48057.png"
  },
  {
    "revision": "d8536e6839813adbe87170e52ba4f633",
    "url": "./static/media/trending_hero_mobile.d8536e68.png"
  },
  {
    "revision": "7d6474cffa27e588429f4d8ec8c951f2",
    "url": "./static/media/trending_hero_tablet.7d6474cf.png"
  },
  {
    "revision": "a1107816561593d68a580ba7f16f44d9",
    "url": "./static/media/trending_icon.a1107816.svg"
  },
  {
    "revision": "9404486ca8950369f3af9c82fbf95172",
    "url": "./static/media/trending_soon_hero_laptop.9404486c.png"
  },
  {
    "revision": "91af3aaa324fb39b2e8bc0648be25688",
    "url": "./static/media/trending_soon_hero_mobile.91af3aaa.png"
  },
  {
    "revision": "c66b9af5590baecbc3bea28687f86201",
    "url": "./static/media/trending_soon_hero_tablet.c66b9af5.png"
  },
  {
    "revision": "ee7d5a20e000f52754f2ad5210092bb9",
    "url": "./static/media/trezor.ee7d5a20.svg"
  },
  {
    "revision": "edcc1ab5dde5cb3d5cf134c4aade641b",
    "url": "./static/media/trustWallet.edcc1ab5.png"
  },
  {
    "revision": "2cd4475f69a736abf5ba84b909793095",
    "url": "./static/media/tx-banner.2cd4475f.png"
  },
  {
    "revision": "e47d1cfccf0203caa8bad38a2b01649a",
    "url": "./static/media/uniswap-icon.e47d1cfc.svg"
  },
  {
    "revision": "02b4ccefb5a4f00a5deddd36efc08613",
    "url": "./static/media/unslashed.02b4ccef.svg"
  },
  {
    "revision": "e13a7f1f07e566185cb905dc52c5ff8d",
    "url": "./static/media/unslashed_light.e13a7f1f.svg"
  },
  {
    "revision": "2dd81b1d98267e7f79d6aa7bb8340fc3",
    "url": "./static/media/vi-VN.2dd81b1d.po"
  },
  {
    "revision": "7ff6bc31244daa371b10978c7fae177b",
    "url": "./static/media/wallet-connect.7ff6bc31.svg"
  },
  {
    "revision": "20237ee2d3963575d45eb1d462e653d8",
    "url": "./static/media/wallet-link.20237ee2.svg"
  },
  {
    "revision": "5e81cac236fd057cb686399a8fa2ea57",
    "url": "./static/media/walletConnectIcon.5e81cac2.svg"
  },
  {
    "revision": "1199f09d594c5245b83e964712d9c9a9",
    "url": "./static/media/warning-icon.1199f09d.svg"
  },
  {
    "revision": "183ea9c72cf77df9e815950508a78315",
    "url": "./static/media/warning.183ea9c7.svg"
  },
  {
    "revision": "5b8e218668bfea1d44b887bd042f6a52",
    "url": "./static/media/x.5b8e2186.svg"
  },
  {
    "revision": "9752664f2407f11026475ed6ab6c3583",
    "url": "./static/media/zh-CN.9752664f.po"
  }
]);